# has_compiler: returns the value of the has_compiler option

    Code
      has_compiler()
    Condition
      Error in `has_compiler()`:
      ! 
      ! Invalid `pkgbuild.has_compiler` option.
      i It must be `TRUE` or `FALSE`, not an integer vector.

