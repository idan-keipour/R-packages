# modi 0.1.1.9000

To be released as 0.1.1

## Improvements

Flat outputs from detection and imputation functions.

Complex survey data set lival. 

Plotting as separate function

## Bug fixes
Coherence between examples and functions. 

## modi 0.1.1
This is the second release of the package modi.
