library(testthat)
library(modi)

test_check("modi")
