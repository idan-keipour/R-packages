library(testthat)
library(qpdf)

test_check("qpdf")
