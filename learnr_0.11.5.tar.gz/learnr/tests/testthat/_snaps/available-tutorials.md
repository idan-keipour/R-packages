# Tutorial names are retrieved

    Code
      available_tutorials("learnr")
    Output
      Available tutorials:
      * learnr
        - ex-data-basics    : "Data basics"
        - ex-data-filter    : "Filter observations"
        - ex-data-mutate    : "Create new variables"
        - ex-data-summarise : "Summarise Tables"
        - ex-setup-r        : "Set Up"
        - hello             : "Hello, Tutorial!"
        - polyglot          : "Multi-language exercises"
        - quiz_question     : "Tutorial Quiz Questions in `learnr`"
        - setup-chunks      : "Chained setup chunks"
        - slidy             : "Slidy demo"
        - sql-exercise      : "Interactive SQL Exercises" 

